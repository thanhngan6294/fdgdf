#include "dbeditmainwindow.h"
#include <QApplication>
#include <QDebug>
#include <QStringList>
#include <QRegularExpression>
#include "tabdialog.h"
#include "tabdialogSignalMessage.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    DbEditMainWindow w;
    QString line(" SG_ PWM_CVVAL : 48|16@1+ (6.103515625E-005,0) [0|1] \"\"  NODE1");
    QStringList lineItems2 =  line.split(QRegularExpression(":| |@|\\||\\(|\\)|\\[|\\]|,|\\+"),QString::SkipEmptyParts);//|([A-Za-z]\w+)
    qDebug()<<lineItems2.size() << lineItems2;
    // Qt framework using an easy way to split a line into separate words
    w.show();
    return a.exec();
}
